"""MCP bridge package."""

