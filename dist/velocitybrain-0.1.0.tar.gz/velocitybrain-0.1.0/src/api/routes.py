from fastapi import APIRouter, HTTPException

from src.models.api import (
    AccessTokenRequest,
    AgentRunRequest,
    AgentRunResponse,
    CollaborateRequest,
    CommandRequest,
    DecideRequest,
    EvalQueryRequest,
    IngestTextRequest,
    LegacyPlanRequest,
    MultimodalIngestRequest,
    OrgIngestRequest,
    PredictRequest,
    QueryRequest,
    QueryResponse,
    SimulateRequest,
    SyncRequest,
    WorkflowExecuteRequest,
)
from src.services.access_control import AccessControlService
from src.services.agent_loop import AgentLoop
from src.services.command_router import CommandRouter
from src.services.dashboard_service import DashboardService
from src.services.decision_engine import DecisionEngine
from src.services.evaluation_service import EvaluationService
from src.services.execution_engine import ExecutionEngine
from src.services.graph_service import GraphService
from src.services.identity_spec import IdentitySpecService
from src.services.memory_engine import MemoryEngine
from src.services.multimodal_ingest import MultimodalIngestService
from src.services.multi_agent_engine import MultiAgentEngine
from src.services.org_ingest import OrgIngestService
from src.services.predictive_engine import PredictiveEngine
from src.services.retrieval_engine import RetrievalEngine
from src.services.simulation_engine import SimulationEngine
from src.services.skill_registry import SkillRegistry
from src.services.sync_service import SyncService
from src.services.temporal_engine import TemporalEngine

router = APIRouter(prefix='/v1')
memory = MemoryEngine()
retrieval = RetrievalEngine()
agent = AgentLoop()
graph = GraphService()
skills = SkillRegistry('skills')
multimodal = MultimodalIngestService()
org_ingest = OrgIngestService()
temporal = TemporalEngine()
predictive = PredictiveEngine()
simulator = SimulationEngine()
decision = DecisionEngine()
collab = MultiAgentEngine()
dashboard = DashboardService()
commands = CommandRouter()
execution = ExecutionEngine()
sync = SyncService()
identity = IdentitySpecService()
eval_service = EvaluationService()
access = AccessControlService()


@router.post('/ingest/text')
def ingest_text(req: IngestTextRequest):
    return memory.upsert_from_text(req.source, req.content, req.access_level)


@router.post('/ingest/org')
def ingest_org(req: OrgIngestRequest):
    return org_ingest.ingest_content(source=req.source, content=req.content, access_level=req.access_level)


@router.post('/ingest/multimodal')
def ingest_multimodal(req: MultimodalIngestRequest):
    return multimodal.ingest(req.source, req.modality, req.content, req.metadata, req.access_level)


@router.post('/query', response_model=QueryResponse)
def query(req: QueryRequest):
    try:
        hits = retrieval.hybrid_search(req.question, req.limit)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f'database unavailable: {exc}') from exc

    if not hits:
        return QueryResponse(
            answer='The internal brain does not currently contain sufficient data for this question.',
            confidence=0.22,
            references=[],
            reasoning_summary='Brain-first lookup completed with zero hits. No hallucinated answer returned.',
        )

    top = hits[0]
    answer = f"{top['title']}: {top['compiled_truth_md'][:400]}"
    refs = [{'type': 'entity', 'slug': h['slug'], 'title': h['title']} for h in hits]
    return QueryResponse(
        answer=answer,
        confidence=float(top['confidence']),
        references=refs,
        reasoning_summary=f'Hybrid retrieval returned {len(hits)} internal matches; top-ranked entity used for synthesis.',
    )


@router.post('/eval/query')
def eval_query(req: EvalQueryRequest):
    return eval_service.eval_query(req.question, req.expected_slugs, req.k)


@router.get('/query/timeline-changes/{slug}')
def timeline_changes(slug: str, days: int = 30):
    result = temporal.changes_for_entity(slug, days=days)
    if not result.get('entity'):
        raise HTTPException(status_code=404, detail='entity not found')
    return result


@router.post('/agent/run', response_model=AgentRunResponse)
def run_agent(req: AgentRunRequest):
    result = agent.run(req.signal)
    return AgentRunResponse(
        run_id=result['run_id'],
        status=result['status'],
        intent=result['intent'],
        plan=result['plan'],
        actions=result['actions'],
        memory_updates=result['memory_updates'],
        confidence=result['confidence'],
    )


@router.post('/agents/collaborate')
def collaborate(req: CollaborateRequest):
    return collab.collaborate(req.objective, req.agents)


@router.post('/predict')
def predict(req: PredictRequest):
    return predictive.forecast(req.subject, req.horizon_days)


@router.post('/simulate')
def simulate(req: SimulateRequest):
    return simulator.run(req.scenario, req.options)


@router.post('/decide')
def decide(req: DecideRequest):
    return decision.analyze(req.decision, req.options, req.constraints)


@router.post('/execute/workflow')
def execute_workflow(req: WorkflowExecuteRequest):
    return execution.execute_workflow(req.workflow_key, req.payload)


@router.post('/command')
def command(req: CommandRequest):
    return commands.dispatch(req.command)


@router.get('/entity/{slug}')
def get_entity(slug: str):
    e = memory.get_entity(slug)
    if not e:
        raise HTTPException(status_code=404, detail='entity not found')
    return e


@router.get('/graph/entity/{slug}')
def get_graph(slug: str):
    return graph.get_entity_neighbors(slug)


@router.get('/skills')
def list_skills():
    all_skills = skills.list_skills()
    return {'count': len(all_skills), 'skills': all_skills}


@router.get('/identity/spec')
def identity_spec():
    return identity.get()


@router.post('/access/token')
def mint_access_token(req: AccessTokenRequest):
    return access.mint_access_token(req.actor, req.scopes, req.ttl_seconds)


@router.post('/legacy/plan')
def save_legacy_plan(req: LegacyPlanRequest):
    return access.save_legacy_plan(req.owner, req.beneficiaries, req.instructions)


@router.get('/legacy/plan/{owner}')
def load_legacy_plan(owner: str):
    try:
        return access.load_legacy_plan(owner)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get('/dashboard/summary')
def dashboard_summary():
    return dashboard.summary()


@router.post('/sync/push')
def sync_push(req: SyncRequest):
    return sync.push(repos=req.repos, dry_run=req.dry_run)


@router.post('/sync/pull')
def sync_pull(req: SyncRequest):
    return sync.pull(repos=req.repos, dry_run=req.dry_run)


@router.post('/sync/full')
def sync_full(req: SyncRequest):
    return sync.full_sync(repos=req.repos, dry_run=req.dry_run)


@router.get('/healthz')
def healthz():
    return {'ok': True}
