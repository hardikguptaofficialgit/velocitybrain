from fastapi import FastAPI
from src.api.routes import router
from src.background.scheduler import start_scheduler
from src.core.config import settings

app = FastAPI(title=settings.app_name, version='1.0.0')
app.include_router(router)


@app.on_event('startup')
def _startup():
    start_scheduler()


@app.get('/')
def root():
    return {
        'app': settings.app_name,
        'mode': 'api-and-cli',
        'docs': '/docs',
        'health': '/v1/healthz',
    }
