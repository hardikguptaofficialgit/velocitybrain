from pydantic import BaseModel, Field
from typing import Any


class IngestTextRequest(BaseModel):
    source: str
    content: str
    access_level: str = 'private'


class OrgIngestRequest(BaseModel):
    source: str = 'org'
    content: str
    access_level: str = 'private'


class QueryRequest(BaseModel):
    question: str
    limit: int = 10


class AgentRunRequest(BaseModel):
    signal: str


class MultimodalIngestRequest(BaseModel):
    source: str
    modality: str
    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    access_level: str = 'private'


class EntityResponse(BaseModel):
    slug: str
    type: str
    title: str
    compiled_truth_md: str
    confidence: float
    timeline: list[dict[str, Any]] = Field(default_factory=list)


class QueryResponse(BaseModel):
    answer: str
    confidence: float
    references: list[dict[str, Any]]
    reasoning_summary: str


class AgentRunResponse(BaseModel):
    run_id: str
    status: str
    intent: str
    plan: list[dict[str, Any]]
    actions: list[dict[str, Any]]
    memory_updates: list[dict[str, Any]]
    confidence: float


class PredictRequest(BaseModel):
    subject: str
    horizon_days: int = 30


class SimulateRequest(BaseModel):
    scenario: str
    options: list[str] = Field(default_factory=list)


class DecideRequest(BaseModel):
    decision: str
    options: list[str]
    constraints: dict[str, Any] = Field(default_factory=dict)


class CollaborateRequest(BaseModel):
    objective: str
    agents: list[str] = Field(default_factory=lambda: ['researcher', 'planner', 'executor'])


class CommandRequest(BaseModel):
    command: str


class WorkflowExecuteRequest(BaseModel):
    workflow_key: str
    payload: dict[str, Any] = Field(default_factory=dict)


class SyncRequest(BaseModel):
    repos: list[str] = Field(default_factory=list)
    dry_run: bool = True


class EvalQueryRequest(BaseModel):
    question: str
    expected_slugs: list[str] = Field(default_factory=list)
    k: int = 5

class AccessTokenRequest(BaseModel):
    actor: str
    scopes: list[str] = Field(default_factory=list)
    ttl_seconds: int = 3600


class LegacyPlanRequest(BaseModel):
    owner: str
    beneficiaries: list[str] = Field(default_factory=list)
    instructions: str
