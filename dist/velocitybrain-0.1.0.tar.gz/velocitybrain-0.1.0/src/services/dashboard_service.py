from src.core.db import get_conn
from src.services.skill_registry import SkillRegistry


class DashboardService:
    def __init__(self):
        self.skills = SkillRegistry('skills')

    def summary(self) -> dict:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT COUNT(*) AS c FROM entities')
                entities = cur.fetchone()['c']
                cur.execute('SELECT COUNT(*) AS c FROM timeline_events')
                timeline = cur.fetchone()['c']
                cur.execute('SELECT run_id, status, intent, confidence, created_at FROM agent_runs ORDER BY created_at DESC LIMIT 10')
                recent_runs = cur.fetchall()
                cur.execute('SELECT slug, title, type, updated_at FROM entities ORDER BY updated_at DESC LIMIT 10')
                recent_entities = cur.fetchall()
        return {
            'kpis': {
                'entities': entities,
                'timeline_events': timeline,
                'enabled_skills': len(self.skills.list_skills()),
            },
            'recent_runs': recent_runs,
            'recent_entities': recent_entities,
        }
