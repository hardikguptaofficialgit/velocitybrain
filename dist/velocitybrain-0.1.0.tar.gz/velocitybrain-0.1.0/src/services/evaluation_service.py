from time import perf_counter

from src.services.retrieval_engine import RetrievalEngine


class EvaluationService:
    def __init__(self):
        self.retrieval = RetrievalEngine()

    def eval_query(self, question: str, expected_slugs: list[str], k: int = 5) -> dict:
        started = perf_counter()
        hits = self.retrieval.hybrid_search(question, limit=max(k, 1))
        latency_ms = round((perf_counter() - started) * 1000, 3)

        got = [h.get('slug') for h in hits[:k]]
        expected_set = set(expected_slugs)
        hit_count = sum(1 for slug in got if slug in expected_set)
        precision_at_k = round(hit_count / max(1, k), 4)
        recall_at_k = round(hit_count / max(1, len(expected_set)), 4) if expected_set else 0.0

        return {
            'question': question,
            'k': k,
            'latency_ms': latency_ms,
            'precision_at_k': precision_at_k,
            'recall_at_k': recall_at_k,
            'returned_slugs': got,
            'expected_slugs': expected_slugs,
        }
