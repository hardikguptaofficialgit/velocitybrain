import re
from src.core.db import get_conn


class RetrievalEngine:
    def _expand_queries(self, query: str) -> list[str]:
        q = query.strip()
        lowered = q.lower()
        expansions = [q]
        if lowered.startswith('what do i know about '):
            expansions.append(q.replace('What do I know about', 'Summary of', 1))
        if 'meeting' in lowered:
            expansions.append(f"{q} timeline")
        if 'pattern' in lowered:
            expansions.append(f"{q} trend")
        return list(dict.fromkeys(expansions))

    def keyword_search(self, query: str, limit: int = 10) -> list[dict]:
        tokens = [t for t in re.split(r'\W+', query.lower()) if t]
        if not tokens:
            return []
        like_fragments = [f"%{t}%" for t in tokens]
        sql = """
        SELECT slug, type, title, compiled_truth_md, confidence
        FROM entities
        WHERE (
          LOWER(title) LIKE ANY(%s)
          OR LOWER(compiled_truth_md) LIKE ANY(%s)
          OR LOWER(slug) LIKE ANY(%s)
        )
        ORDER BY confidence DESC, updated_at DESC
        LIMIT %s
        """
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (like_fragments, like_fragments, like_fragments, limit))
                return cur.fetchall()

    def hybrid_search(self, query: str, limit: int = 10) -> list[dict]:
        # Multi-query keyword retrieval + reciprocal-rank-like fusion.
        all_hits: dict[str, dict] = {}
        expansions = self._expand_queries(query)[:4]
        for qidx, q in enumerate(expansions):
            hits = self.keyword_search(q, limit=min(30, limit * 3))
            for ridx, h in enumerate(hits):
                key = h['slug']
                score = 1.0 / (40 + ridx + (qidx * 2))
                if key not in all_hits:
                    all_hits[key] = {**h, '_fusion_score': score}
                else:
                    all_hits[key]['_fusion_score'] += score

        ranked = sorted(
            all_hits.values(),
            key=lambda x: (x['_fusion_score'], x['confidence']),
            reverse=True,
        )
        for row in ranked:
            row.pop('_fusion_score', None)
        return ranked[:limit]
